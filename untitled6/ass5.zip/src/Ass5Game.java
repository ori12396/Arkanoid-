//207632795


import game.Game;

/**
 * @author ori zohar.
 * assigment 3 class.
 */
public class Ass5Game {
    /**
     * main method.
     *
     * @param args arguments from the command lines.
     */
    public static void main(String[] args) {
        Game game = new Game();
        game.initialize();
        game.run();
    }
}
